document.getElementById("feedbackForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const message = document.getElementById("message").value.trim();

  if (name && message) {
    document.getElementById("response").innerText =
      "Terima kasih atas masukanmu, " + name + "!";
    this.reset();
  }
});